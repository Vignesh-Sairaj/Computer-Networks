compile with -std=c++11 option

outputs 2 files (one for the sender and one for the receiver)
Generate exponential distribution to model arrival times and bernoulli for bit errors (binomial for numErrors).

Compiles and runs correctly.